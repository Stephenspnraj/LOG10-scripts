import pandas as pd
import sys
from utils import DBManager, post_message_to_slack, post_message_to_slack_using_hook
from config import Config
from datetime import datetime, timedelta,date
import datetime as dt
import time



Yesterday = dt.datetime.strftime((date.today()- timedelta(days = 1)),"%Y-%m-%d")



configObj = Config()
db = DBManager(configObj.hydra_prime_credentials)
log10_consignments =  db.fetchData(f"""select c.waybill_no,c.partner_id,c.location_id as consignmets_location_id,c.booking_office_loc_id , SUBSTRING_INDEX(GROUP_CONCAT(ct.event_type ORDER BY ct.event_time desc), ",", 1) as consignment_tracking_event_type,SUBSTRING_INDEX(GROUP_CONCAT(ct.location_id ORDER BY ct.event_time desc), ",", 1) as consignment_tracking_location_id, c.consignment_status,SUBSTRING_INDEX(GROUP_CONCAT(ct.event_time ORDER BY ct.event_time desc), ",", 1) as consignment_tracking_event_time,c.created_at from consignments c inner join consignment_tracking ct on c.waybill_no = ct.waybill_number where c.created_at BETWEEN "2022-12-16 00:00:00" and "{Yesterday} 23:59:59" group by c.waybill_no,c.location_id,c.consignment_status,c.partner_id""").fetchall()
db.close()



df = pd.DataFrame(log10_consignments)
df['consignment_tracking_event_time']=pd.to_datetime(df['consignment_tracking_event_time'])
df




Map =[{'BOOKING_CANCELLED': 'BOOKING_CANCELLED',
  'DELIVERED': 'DEL',
  'DRS_SCAN': 'OFD',
  'DRS_SCAN_DELINK': 'IN',
  'INSCAN': 'INWARD',
  'INWARD_SCAN': 'INWARD',
  'MANIFEST_RECEIVED': 'MANIFEST_RECEIVED',
  'MANIFEST_SCAN': 'MANI_LINK',
  'MANIFEST_SCAN_DELINK': 'RTO_IN',
  'OUT_FOR_PICKUP': 'OFP',
  'PICKED_UP': 'PSUCC',
  'PICKUP_CANCELLED': 'PCANC',
  'PICKUP_CREATED': 'PCREATED',
  'RTO_DELIVERED': 'RTODEL',
  'RTO_UNDELIVERED': 'RTOUNDEL',
  'THC_SCAN': 'IN_TRANSIT',
  'UNDELIVERED': 'UNDEL',
  'UPDATE_RTO_RTS': 'RTO_IN',
  'VEHICLE_ARRIVED': 'VEHICLE_ARRIVED',
  'UPDATE_STATUS': 'RTO_IN',
  'CONSIGNMENT_MARKED_LOST': 'SL',
  'RTO_INWARD_SCAN': 'RTO_INWARD',
  'RTO_DRS_SCAN': 'RTO OUT',
  'SHORTAGE_SCAN': 'SHORTAGE',
  'OVERAGE_SCAN': 'INWARD',
  'WRONG_FACILITY_SCAN': 'WRONG_FACILITY'},
 {'DRS_SCAN_DELINK': 'INWARD',
  'INSCAN': 'IN',
  'MANIFEST_RECEIVED': 'RTO_MANI_RECEIVED',
  'MANIFEST_SCAN': 'RTO_MANI_LINK',
  'MANIFEST_SCAN_DELINK': 'INWARD',
  'THC_SCAN': 'RTO_INTRANSIT',
  'UPDATE_RTO_RTS': 'RTO',
  'VEHICLE_ARRIVED': 'RTO_VEHICLE_ARRIVED',
  'UPDATE_STATUS': 'RTO',
  'SHORTAGE_SCAN': 'RTO_SHORTAGE',
  'OVERAGE_SCAN': 'MISROUTE'},
 {'OVERAGE_SCAN': 'RTO_MISROUTE'},
 {'PICKED_UP': 'IN_TRANSIT'}]


df = df[(df['booking_office_loc_id']!= 5880368) &  (df['booking_office_loc_id']!= 5880208) ]
df=df.reset_index(drop=True)
df = pd.merge(df,pd.DataFrame(Map).T,left_on='consignment_tracking_event_type',right_index=True,how='left').rename(columns={0:'CS_01',1:'CS_02',2:'CS_03',3:'CS_04'}).sort_values(by = ['waybill_no','created_at'],ascending=False).reset_index(drop=True)
df['consignmets_location_id'] = df['consignmets_location_id'].astype('int')
df['consignment_tracking_location_id']=df['consignment_tracking_location_id'].astype('int')
df 



Brack1 = []
Brack2 = []
Brack3 = []
for i in range(len(df)):
    if df['consignment_status'][i] != df['CS_01'][i] and df['consignment_status'][i] != df['CS_02'][i] and df['consignment_status'][i] != df['CS_03'][i] and df['consignment_status'][i] != df['CS_04'][i] and df['consignment_status'][i] != df['consignment_tracking_event_type'][i]:
        Brack1.append((df['waybill_no'][i],df['consignment_status'][i],df['consignment_tracking_event_type'][i]))
        pass

    if df['consignment_tracking_event_type'][i] =='BOOKING': 
        if df['consignment_status'][i] in ('BOOK','PCREATED','IN_TRANSIT','RTO_INTRANSIT')  and df['partner_id'][i] not in (268,269) and int(df['consignmets_location_id'][i]) != int(df['consignment_tracking_location_id'][i]) and df['created_at'][i] == df['consignment_tracking_event_time'][i] :
            Brack2.append(( df['waybill_no'][i],df['partner_id'][i],df['consignmets_location_id'][i],df['consignment_tracking_location_id'][i],df['consignment_tracking_event_type'][i],df['consignment_status'][i],df['created_at'][i],df['consignment_tracking_event_time'][i]))
    elif int(df['consignmets_location_id'][i]) != int(df['consignment_tracking_location_id'][i]):
        Brack3.append(( df['waybill_no'][i],df['partner_id'][i],df['consignmets_location_id'][i],df['consignment_tracking_location_id'][i],df['consignment_tracking_event_type'][i],df['consignment_status'][i],df['created_at'][i]))

Booking_event = pd.DataFrame(Brack2).rename(columns={0:"waybill_no",1:"partner_id",2:"consignmets_location_id",3:"consignment_tracking_location_id",4:"consignment_tracking_event_type",5:"consignment_status",6:"Consignments:created_at",7:"consignment_tracking_event_time"})

location_Log_Data = pd.DataFrame(Brack3)
location_Log_Data=location_Log_Data.rename(columns={0:'Waybill_no',1:'Consignment: Partner_id',2:'Consignment: location_id',3:'Consignments Tracking:location_id',4:'Consignments Tracking: Status',5:'Consignments : Status',6:'Created_at'})
location_Log_Data= location_Log_Data.sort_values(by = 'Waybill_no')


location_Log_Data =location_Log_Data[(location_Log_Data['Consignments Tracking: Status'] !='BOOKING') & (location_Log_Data['Consignments : Status']!='RTO_HANDOVER') ]
location_Log_Data = location_Log_Data.drop(columns=['Consignments Tracking: Status','Consignments : Status'])
location_Log_Data =location_Log_Data.reset_index(drop=True)
location_Log_Data1 = location_Log_Data[:int(len(location_Log_Data)/2)]
location_Log_Data2 = location_Log_Data[int(len(location_Log_Data)/2):]
location_Log_Data2



Status_Log_Data = pd.DataFrame(Brack1)
Status_Log_Data=Status_Log_Data.rename(columns={0:'Waybill_no',1:'Consignment: Consignments_status',2:'Consignments Tracking:Event_type'})
Status_Log_Data = Status_Log_Data.sort_values(by=['Consignment: Consignments_status','Consignments Tracking:Event_type']).reset_index(drop=True)
Status_Log_Data


Pivot_Status_Log_Data = pd.DataFrame(Status_Log_Data.groupby(['Consignment: Consignments_status','Consignments Tracking:Event_type']).size()).rename(columns={0:'counts'})
Pivot_Status_Log_Data = Pivot_Status_Log_Data.sort_values(by='counts',ascending=False)
Pivot_Status_Log_Data =Pivot_Status_Log_Data.reset_index()
Pivot_Status_Log_Data



Pivot_location_Log_Data= pd.DataFrame(location_Log_Data.groupby(['Consignment: location_id','Consignments Tracking:location_id']).size()).rename(columns={0:'counts'})
Pivot_location_Log_Data=Pivot_location_Log_Data.sort_values(by='counts',ascending=False)
Pivot_location_Log_Data = Pivot_location_Log_Data.reset_index()
Pivot_location_Log_Data



#writer1= pd.ExcelWriter("Booking_Log_Data_16Dec-22Dec.xlsx")
#Booking_event.to_excel(writer1,sheet_name="Booking_event",index=False)
#for j in ('A','B','C','D','E','F','G','H'):
#    writer1.sheets['Booking_event'].column_dimensions[j].width = 40
#writer1.save()

writer1= pd.ExcelWriter("Log_Data_9Dec-16Dec.xlsx")
Status_Log_Data.to_excel(writer1,sheet_name='Status_Log_Data',index=False)
Pivot_Status_Log_Data.to_excel(writer1,sheet_name='Pivot_Status_Log_Data',index=False)
location_Log_Data1.to_excel(writer1,sheet_name='location_Log_Data1',index=False)
location_Log_Data2.to_excel(writer1,sheet_name='location_Log_Data2',index=False)
Pivot_location_Log_Data.to_excel(writer1,sheet_name='Pivot_location_Log_Data',index=False)
writer1.sheets['Status_Log_Data'].column_dimensions['A'].width = 22

for i in ('Status_Log_Data','Pivot_Status_Log_Data','Pivot_location_Log_Data','location_Log_Data1','location_Log_Data2'):
     for j in ('A','B','C','D','E','F'):
         writer1.sheets[i].column_dimensions[j].width = 40
        
    
writer1.save()

