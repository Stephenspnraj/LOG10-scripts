#!/bin/bash
set -e
ssh -L 3310:log10-replica-replica.cco3osxqlq4g.ap-south-1.rds.amazonaws.com:3306 ubuntu@log10-jb.loadshare.net -N
