import pymysql
import pandas as pd

# Database connection details
mysql_host = 'prod-titan-rds.cco3osxqlq4g.ap-south-1.rds.amazonaws.com'
mysql_port = 3306  # Assuming default MySQL port
mysql_user = 'prod_titan_app'
mysql_password = '7Xc8ZG0bEpFTkhrrGoRAlhaP5qV9zSkfEagQ'
mysql_db = 'titan'

# Read data from CSV file
input_file = 'user_migration.csv'
df = pd.read_csv(input_file)

# Create a database connection
conn = pymysql.connect(
    host=mysql_host,
    port=mysql_port,
    user=mysql_user,
    password=mysql_password,
    db=mysql_db,
    charset='utf8mb4',
    cursorclass=pymysql.cursors.DictCursor
)

# Function to execute the query and stored procedure
def execute_query(contact_number, location_id):
    query = f"""
    SELECT
        CONCAT('call update_users_ecom(', u.id, ',', h.id, ',', h.organization_id, ');') AS call_statement
    FROM
        users u
    JOIN
        hubs h ON h.name IN (SELECT name FROM zones WHERE order_broker = '{location_id}')
    WHERE
        u.contact_number IN ('{contact_number}')
        AND u.role = 3
         and h.is_active=1
    and h.primary_operation='ECOM'
        AND u.is_active = 1;
    """
    with conn.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()  # Use fetchone() since only one row is expected

    if not result:
        print(f'No results for contact_number={contact_number} and location_id={location_id}')
    else:
        call_statement = result['call_statement']
        print(f'Executing: {call_statement}')
        try:
            with conn.cursor() as exec_cursor:
                exec_cursor.execute(call_statement)
                conn.commit()
                print(f'Successfully executed: {call_statement}')
        except Exception as e:
            print(f'Error executing {call_statement}: {e}')

# Loop through the CSV data
for index, row in df.iterrows():
    contact_number = row['contact_number']
    location_id = row['location_id']
    execute_query(contact_number, location_id)

# Close the database connection
conn.close()
