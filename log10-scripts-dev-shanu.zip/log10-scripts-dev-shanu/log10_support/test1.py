print("hello Log10 scriprts")
