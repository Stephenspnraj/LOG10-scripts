import requests
from datetime import datetime, timedelta
import pytz
import time

# Configuration
FRESHDESK_DOMAIN = "log10-support"
API_KEY = "s2yYv2EIdGZ9s3URmNEy"
#SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/T4T51HS4D/B0u2PDHLP0NqASGbu0KV"
SLACK_WEBHOOK_URL = "https://hooks.slack.com/services/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"

# Constants
BASE_URL = f"https://{FRESHDESK_DOMAIN}.freshdesk.com/api/v2"
FM_TAG = "fm"
LM_TAG = "lm"
URGENT_PRIORITIES = [3, 4]
OPEN_STATUSES = [2]
WAITING_AT_DEV_STATUS = 8

IST = pytz.timezone('Asia/Kolkata')

def convert_to_ist(utc_date_str):
    utc_datetime = datetime.strptime(utc_date_str, "%Y-%m-%dT%H:%M:%SZ")
    utc_datetime = utc_datetime.replace(tzinfo=pytz.utc)
    return utc_datetime.astimezone(IST)

def fetch_all_tickets():
    tickets = []
    page = 1
    query = 'status:2 OR status:8'

    while True:
        url = f"{BASE_URL}/search/tickets?query=\"{query}\"&page={page}"
        try:
            response = requests.get(url, auth=(API_KEY, "X"), headers={"Content-Type": "application/json"})
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 5))
                time.sleep(retry_after)
                continue
            response.raise_for_status()
            data = response.json()
            results = data.get("results", [])
            if not results:
                break
            tickets.extend(results)
            page += 1
        except requests.exceptions.RequestException as err:
            print(f"Failed to fetch page {page}: {err}")
            break
    return tickets

def categorize_tickets(tickets):
    today_ist = datetime.now(IST)
    d1_cutoff = today_ist - timedelta(days=1)
    d2_cutoff = today_ist - timedelta(days=2)

    categories = {
        "FM Locations": [],
        "LM Locations": [],
        "Urgent Tickets": [],
        "Tickets older than D-2+": [],
        "D-1 Tickets": [],
        "D-0 Tickets": [],
        "Waiting at Dev": [],
    }

    for ticket in tickets:
        created_at_ist = convert_to_ist(ticket["created_at"])
        created_at_date = created_at_ist.date()

        if ticket["status"] == WAITING_AT_DEV_STATUS:
            categories["Waiting at Dev"].append(ticket)
            continue  # exclude from all other buckets

        # Only status == 2 (Open) tickets from here on
        if FM_TAG in ticket.get('tags', []):
            categories["FM Locations"].append(ticket)
        elif LM_TAG in ticket.get('tags', []):
            categories["LM Locations"].append(ticket)

        if ticket["priority"] in URGENT_PRIORITIES:
            categories["Urgent Tickets"].append(ticket)

        if created_at_date == today_ist.date():
            categories["D-0 Tickets"].append(ticket)
        elif created_at_date == d1_cutoff.date():
            categories["D-1 Tickets"].append(ticket)
        elif created_at_date <= d2_cutoff.date():
            categories["Tickets older than D-2+"].append(ticket)

    # Deduplication
    fm_lm_ids = {t["id"] for t in categories["FM Locations"] + categories["LM Locations"]}
    categories["Urgent Tickets"] = [t for t in categories["Urgent Tickets"] if t["id"] not in fm_lm_ids]

    return categories


def format_ticket_ids_with_age(tickets, category_name):
    today = datetime.now(IST).date()

    if category_name in ["D-0 Tickets", "D-1 Tickets"]:
        return ", ".join([str(t["id"]) for t in tickets])
    else:
        return ", ".join([
            f"{t['id']}(d-*{(today - convert_to_ist(t['created_at']).date()).days}*)"
            for t in tickets
        ])

def send_to_slack(message):
    payload = {"text": message}
    try:
        response = requests.post(SLACK_WEBHOOK_URL, json=payload)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"Error sending to Slack: {e}")

def main():
    tickets = fetch_all_tickets()
    categorized = categorize_tickets(tickets)

    report_lines = []
    report_lines.append(f"*Unresolved Ticket Breakdown as of {datetime.now(IST).strftime('%Y-%m-%d %H:%M:%S')}*")
    report_lines.append("---------------------------")
    report_lines.append(f"* Total Tickets (Open + Waiting at Dev)* : *{len(tickets)}*")

    for key in [
        "FM Locations",
        "LM Locations",
        "Urgent Tickets",
        "Tickets older than D-2+",
        "D-1 Tickets",
        "D-0 Tickets",
        "Waiting at Dev",
    ]:
        ticket_list = categorized[key]
        if ticket_list:
            report_lines.append(f"- `{key}`: *{len(ticket_list)}* [Ticket IDs: {format_ticket_ids_with_age(ticket_list, key)}]")
        else:
            report_lines.append(f"- `{key}`: *0*")

    message = "\n".join(report_lines)
    print(message)
    send_to_slack(message)

if __name__ == "__main__":
    main()
