import pandas as pd
import json
import requests
from utils import DBManager, Config
from os import environ
import os


def delink_shipments(entity_type,entity_code,waybill_no):
    if entity_type not in ("MANIFEST" , "DRS" , "RTO_DRS"):
        raise ValueError("Please select any one of these entity type : MANIFEST , DRS , RTO_DRS")

    if len(entity_code.split())==1:
            entity_code = entity_code.split()[0]
    elif len(entity_code.split())>=2:
            raise TypeError("Only one Drs or Manifest code is allow at a time")
    else:
            print("Not a valid input for Drs or Manifest Code")
    
    if len(waybill_no.split())==1:
            waybill_no = waybill_no.split()[0]
            Query = f"""select waybill_no from consignment_groups cg  where entity_code in ("{entity_code}") AND entity_type in ("{entity_type}") AND waybill_no IN ("{waybill_no}")"""
    
    elif len(waybill_no.split())>=2:
            waybill_no = tuple(waybill_no.split())
            Query = f"""select waybill_no from consignment_groups cg  where entity_code in ("{entity_code}") AND entity_type in ("{entity_type}") AND waybill_no IN {waybill_no} """
    else:
            raise TypeError("Not a valid input")
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)
    log10_DRS =  db.fetchData(Query).fetchall()
    
    db.close()
    df = pd.DataFrame(log10_DRS)
    results = []
    if len(df) ==0:
        raise ValueError("We didn't find any DRS/Manifest with Waybills in your input")
    
    elif len(df) == 1 :
        
        update_Command = f"""update consignment_groups set entity_id =0 , entity_type ='NONE' , entity_code='NOTASSIGNED' where entity_code in ("{entity_code}")  and waybill_no in ('{df['waybill_no'][0]}');"""
        # print(update_Command)
        configObj = Config()
        db = DBManager(configObj.hydra_prime_credentials)   
        log10_Consignments_update =  db.fetchData(update_Command).fetchall()
        results.append(update_Command)
        print("Has been sucessfully Delinked")
        if entity_type=="DRS":
                update_Command = f"""update delivery_run_sheet_mappings set is_active = 0 where drs_id =(select distinct id from delivery_run_sheets where drs_code in ("{entity_code}"))  and waybill_no in ('{df['waybill_no'][0]}');"""
                # update_Command = f"""update consignments set consignment_status = 'INWARD' where  waybill_no in ('{df['waybill_no'][0]}')"""
                # print(update_Command)
                configObj = Config()
                db = DBManager(configObj.hydra_prime_credentials)   
                log10_Consignments_update =  db.fetchData(update_Command).fetchall()
                results.append(update_Command)
                update_Command1 = f"""update consignments set consignment_status = 'INWARD' where waybill_no in ('{df['waybill_no'][0]}');"""
                configObj = Config()
                db = DBManager(configObj.hydra_prime_credentials)   
                log10_Consignments_update =  db.fetchData(update_Command1).fetchall()
                results.append(update_Command1)


        elif entity_type=="RTO_DRS":
                update_Command = f"""update rto_delivery_run_sheet_mappings set is_active = 0 where rto_drs_id =(select distinct id from rto_drs where drs_code in ("{entity_code}"))  and waybill_no in ('{df['waybill_no'][0]}');"""
        #         update_Command = f"""update consignments set consignment_status = 'RTO_IN' where  waybill_no in ('{df['waybill_no'][0]}')"""
        #         # print(update_Command)
                configObj = Config()
                db = DBManager(configObj.hydra_prime_credentials)   
                log10_Consignments_update =  db.fetchData(update_Command).fetchall()
                results.append(update_Command)
                update_Command1 = f"""update consignments set consignment_status = 'RTO_IN' where  waybill_no in ('{df['waybill_no'][0]}')"""
                configObj = Config()
                db = DBManager(configObj.hydra_prime_credentials)   
                log10_Consignments_update =  db.fetchData(update_Command1).fetchall()
                results.append(update_Command1)
    else :
        update_Command = f"""update consignment_groups set entity_id =0 , entity_type ='NONE' , entity_code='NOTASSIGNED' where entity_code in ("{entity_code}")  and waybill_no in {tuple([df['waybill_no'][i] for i in range(len(df))])} ;"""
        # print(update_Command)
        configObj = Config()
        db = DBManager(configObj.hydra_prime_credentials)   
        log10_Consignments_update =  db.fetchData(update_Command).fetchall()
        results.append(update_Command)
        print("Has been sucessfully Delinked")
        if entity_type=="DRS":
                  update_Command = f"""update delivery_run_sheet_mappings set is_active = 0 where drs_id =(select distinct id from delivery_run_sheets where drs_code in ("{entity_code}")) and waybill_no in {tuple([df['waybill_no'][i] for i in range(len(df))])} ;"""
                  configObj = Config()
                  db = DBManager(configObj.hydra_prime_credentials)   
                  log10_Consignments_update =  db.fetchData(update_Command).fetchall()
                  results.append(update_Command)
                  if Default_Consignment_Status_Update=="Yes":
                        update_Command1 = f"""update consignments set consignment_status = 'INWARD' where waybill_no in {tuple([df['waybill_no'][i] for i in range(len(df))])} ;"""
                        configObj = Config()
                        db = DBManager(configObj.hydra_prime_credentials)   
                        log10_Consignments_update =  db.fetchData(update_Command1).fetchall()
                        results.append(update_Command1)
        elif entity_type=="RTO_DRS":
                update_Command = f"""update rto_delivery_run_sheet_mappings set is_active = 0 where rto_drs_id =(select distinct id from rto_drs where drs_code in ("{entity_code}"))  and waybill_no in {tuple([df['waybill_no'][i] for i in range(len(df))])} ;"""
                configObj = Config()
                db = DBManager(configObj.hydra_prime_credentials)   
                log10_Consignments_update =  db.fetchData(update_Command).fetchall()
                results.append(update_Command)
                if Default_Consignment_Status_Update=="Yes":
                                update_Command1 = f"""update consignments set consignment_status = 'RTO_IN' where  waybill_no in {tuple([df['waybill_no'][i] for i in range(len(df))])}"""
                                configObj = Config()
                                db = DBManager(configObj.hydra_prime_credentials)   
                                log10_Consignments_update =  db.fetchData(update_Command1).fetchall()
                                results.append(update_Command1)

    if results != [] : 
        message = "\n".join(results)
        SLACK_URL = "https://hooks.slack.com/services/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"
        data = {"attachments": [{
                "title": "Unable to Process or Validate Manifest/DRS \n"+"Updates for delinking shipments are as follows:\n",
                "text": message,
                "color": "#36a64f",
                "mrkdwn_in": ["text"]}]}
        headers = {'Content-type': 'application/json',}

        response = requests.post(SLACK_URL, headers=headers, data=json.dumps(data))

        if response.status_code == 200:
                print("Slack Message sent successfully")
        else:
                print("Slack Message sending failed")
                #     print("Unable to Process or Validate Manifest/DRS \n"+"\nUpdates for delinking shipments are as follows:\n"+message)    




# entity_type = environ["Please Select Entity Type for Processing"]
# entity_code = environ["Please enter the Manifest or Drs Code for Delinking"]
# waybill_no = environ["Please Enter Waybill Number Below"]


entity_type = environ["Entity_Type"]
entity_code = environ["Entity_Code"]
waybill_no = environ["Waybill_No"]
Default_Consignment_Status_Update = environ["Default_Consignment_Status_Update"]


if __name__=="__main__":

    delink_shipments(entity_type,entity_code,waybill_no)

    print("Done")


print("Done")