import pandas as pd
from utils import DBManager, Config
from os import environ
import requests
import json



def Misroute_configs(from_loc,to_loc):
    Query = f"""select id,entity_id from locations where id = {from_loc} """
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_Consignments1 =  db.fetchData(Query).fetchall()
    db.close()
    print(log10_Consignments1[0]['id'],log10_Consignments1[0]['entity_id'])
    
    Query = f"""select id,entity_id from locations where id = {to_loc} """
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_Consignments2 =  db.fetchData(Query).fetchall()
    db.close()
    log10_Consignments2
    print(log10_Consignments2[0]['id'],log10_Consignments2[0]['entity_id'])
    
    Query = f"""select location_id,pincode_id from next_location_configs nlc where location_id in (5879892,5880176,5880968,5881000,5881109,5881108) and  next_location_id = {to_loc} and entity_type = 'manifest' and is_active = 1 and flow_type is null"""
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_nlc =  db.fetchData(Query).fetchall()
    db.close()
    print(log10_nlc[0]['location_id'],log10_nlc[0]['pincode_id'])

    results = [] 
    
    Query = f"""select id from next_location_configs where location_id = {log10_Consignments1[0]['id']} and next_location_id = {log10_nlc[0]['location_id']} and pincode_id = {log10_nlc[0]['pincode_id']} and entity_type = 'MANIFEST' and is_active = 1"""
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_insert_nlc_s =  db.fetchData(Query).fetchall()
    db.close()
    if len(log10_insert_nlc_s)==0:
        Query =f"""INSERT INTO loadshare.next_location_configs (customer_id, location_id, next_location_id, pincode_id, return_available, entity_type, is_active) VALUES(10823,{log10_Consignments1[0]['id']},{log10_nlc[0]['location_id']},{log10_nlc[0]['pincode_id']}, 1, 'MANIFEST', 1);"""
        configObj = Config()
        db = DBManager(configObj.hydra_prime_credentials)   
        log10_insert_nlc =  db.fetchData(Query).fetchall()
        db.close()
        results.append(Query)
    
    
    
    Query =f"""select id from child_booking_location_mapping  where source_location_id = {log10_Consignments1[0]['id']} and destination_location_id =  {log10_Consignments2[0]['id']} and partner_id = {log10_Consignments1[0]['entity_id']};"""
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_insert_cb_s =  db.fetchData(Query).fetchall()
    db.close()
    if len(log10_insert_cb_s)==0:
        Query =f"""INSERT INTO loadshare.child_booking_location_mapping ( source_location_id, destination_location_id, partner_id, customer_id, is_active) VALUES( {log10_Consignments1[0]['id']}, {log10_Consignments2[0]['id']},{log10_Consignments1[0]['entity_id']}, NULL, 1);"""
        configObj = Config()
        db = DBManager(configObj.hydra_prime_credentials)   
        log10_insert_cb =  db.fetchData(Query).fetchall()
        db.close()
        results.append(Query)
    
    
    Query =f"""select id from partner_to_partner_mapping where source_partner_id = {log10_Consignments1[0]['entity_id']} and link_partner_id =  {log10_Consignments2[0]['entity_id']} and is_active = 1 ;"""
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_insert_cb_s =  db.fetchData(Query).fetchall()
    db.close()
    if len(log10_insert_cb_s)==0:
        Query =f"""INSERT INTO loadshare.partner_to_partner_mapping (source_partner_id, link_partner_id, source_location_id, is_active, customer_id) VALUES({log10_Consignments1[0]['entity_id']},{log10_Consignments2[0]['entity_id']}, NULL, 1, 0); """
        configObj = Config()
        db = DBManager(configObj.hydra_prime_credentials)   
        log10_p_to_p =  db.fetchData(Query).fetchall()
        db.close()
        results.append(Query)

    Query =f"""select id from partner_to_partner_mapping where source_partner_id = {log10_Consignments2[0]['entity_id']} and link_partner_id =  {log10_Consignments1[0]['entity_id']} and is_active = 1 ;"""
    configObj = Config()
    db = DBManager(configObj.hydra_prime_credentials)   
    log10_insert_cb_s =  db.fetchData(Query).fetchall()
    db.close()
    if len(log10_insert_cb_s)==0:
        Query =f"""INSERT INTO loadshare.partner_to_partner_mapping (source_partner_id, link_partner_id, source_location_id, is_active, customer_id) VALUES({log10_Consignments2[0]['entity_id']},{log10_Consignments1[0]['entity_id']}, NULL, 1, 0); """
        configObj = Config()
        db = DBManager(configObj.hydra_prime_credentials)   
        log10_p_to_p =  db.fetchData(Query).fetchall()
        db.close()   
        results.append(Query)

    if results !=[]:
                message = "\n".join(results)
                SLACK_URL = "https://hooks.slack.com/services/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"
                data = {"attachments": [{
                    "title": "Unable to create Misroute Bags \n"+"INSERTS are as follows:\n",
                    "text": message,
                    "color": "#36a64f",
                    "mrkdwn_in": ["text"]}]}
                headers = {'Content-type': 'application/json',}

                response = requests.post(SLACK_URL, headers=headers, data=json.dumps(data))

                if response.status_code == 200:
                    print("Slack Message sent successfully")
                else:
                    print("Slack Message sending failed") 


from_loc = environ["source_location_id"]
to_loc = environ["destination_location_id"]

Misroute_configs(from_loc,to_loc)

print("Request Processed")


    
    

    