import pandas as pd
import pymysql

# DB Connection
conn = pymysql.connect(
    host="log10-replica-replica.cco3osxqlq4g.ap-south-1.rds.amazonaws.com",
    user="log10_scripts",
    password="D2lx7Wz0Wm9ISAY-Vp1gxKDTzLRRl5k1m",
    database="loadshare",
    port=3306
)
cursor = conn.cursor()

# ------------------------------------------------------
# 1️⃣ CONDITION 1 (LM to LM multi SC WF checker)
# ------------------------------------------------------
condition1_query = """
SELECT diff.deleted_id
FROM next_location_configs nlc
INNER JOIN (
    SELECT 
        location_id, 
        pincode_id,
        MIN(id) AS deleted_id
    FROM next_location_configs
    WHERE entity_type = 'MANIFEST'
      AND is_active = 1
    GROUP BY location_id, pincode_id
    HAVING COUNT(DISTINCT next_location_id) > 1
) diff
  ON nlc.location_id = diff.location_id
  AND nlc.pincode_id = diff.pincode_id
JOIN locations l ON nlc.location_id = l.id
JOIN locations ln ON nlc.next_location_id = ln.id
JOIN locations dl 
  ON dl.pincode_id = nlc.pincode_id
  AND dl.entity_type = 'PARTNER'
  AND dl.status = 1
  AND dl.is_valmo_location=1
WHERE 
  nlc.entity_type = 'MANIFEST'
  AND nlc.is_active = 1
  AND nlc.audit_log IN ('multi-sc wrong facility','WF_BAGGING_CRON')
ORDER BY 
  nlc.location_id, nlc.pincode_id, nlc.updated_at DESC;
"""

cursor.execute(condition1_query)
condition1_ids = [row[0] for row in cursor.fetchall()]

if condition1_ids:
    update1 = f"""
    UPDATE loadshare.next_location_configs
    SET is_active = 0,
    audit_log = 'Duplicate nlc cleaner job'
    WHERE id IN ({','.join(map(str, condition1_ids))});
    """
    print("🔹 Running Condition1 Update:")
    cursor.execute(update1)
    conn.commit()
else:
    print("✅ No condition1 mismatches found")

# ------------------------------------------------------
# 2️⃣ CONDITION 2 (Wrong connections checker)
# ------------------------------------------------------
duplicate_finder_query = """
SELECT
  nlc.id,
  l.alias AS source,
  ln.alias AS next_location,
  dl.alias AS dest_loc
FROM
  next_location_configs nlc
  INNER JOIN (
      SELECT 
          location_id, 
          pincode_id,
          MIN(id) AS deleted_id
      FROM next_location_configs
      WHERE entity_type = 'MANIFEST'
        AND is_active = 1
      GROUP BY location_id, pincode_id
      HAVING COUNT(DISTINCT next_location_id) > 1
  ) diff
    ON nlc.location_id = diff.location_id
    AND nlc.pincode_id = diff.pincode_id
  JOIN locations l ON nlc.location_id = l.id
  JOIN locations ln ON nlc.next_location_id = ln.id
  JOIN locations dl 
    ON dl.pincode_id = nlc.pincode_id
    AND dl.entity_type = 'PARTNER'
    AND dl.status = 1
    AND dl.is_valmo_location=1
WHERE 
  nlc.entity_type = 'MANIFEST'
  AND nlc.is_active = 1
ORDER BY 
  nlc.location_id, nlc.pincode_id, nlc.updated_at DESC;
"""

cursor.execute(duplicate_finder_query)
duplicates = cursor.fetchall()

invalid_ids = []
report_rows = []

for path_id, source, next_loc, dest_loc in duplicates:
    if next_loc == dest_loc:
        expected = (next_loc, source, source)   # Direct lane
    else:
        expected = (dest_loc, next_loc, source) # Normal reciprocal

    reverse_check_query = """
    SELECT 1
    FROM next_location_configs nlc
    JOIN locations l ON nlc.location_id = l.id
    JOIN locations ln ON nlc.next_location_id = ln.id
    JOIN locations dl ON dl.pincode_id = nlc.pincode_id
      AND dl.entity_type = 'PARTNER'
      AND dl.status = 1
      AND dl.is_valmo_location = 1
    WHERE nlc.entity_type = 'MANIFEST'
      AND nlc.is_active = 1
      AND l.alias = %s
      AND ln.alias = %s
      AND dl.alias = %s
    LIMIT 1;
    """

    cursor.execute(reverse_check_query, expected)
    reverse_exists = cursor.fetchone()

    status = "MATCH" if reverse_exists else "MISMATCH"
    report_rows.append((path_id, source, next_loc, dest_loc, expected, status))

    if not reverse_exists:
        invalid_ids.append(path_id)

# Export report
df = pd.DataFrame(report_rows, columns=['id','source','next_loc','dest_loc','expected_reverse','status'])
df.to_excel("duplicate_mismatch_report.xlsx", index=False)
print("✅ Report generated: duplicate_mismatch_report.xlsx")

# Deactivate mismatches
if invalid_ids:
    update2 = f"""
    UPDATE loadshare.next_location_configs
    SET is_active = 0,
    audit_log = 'Duplicate nlc cleaner job'
    WHERE id IN ({','.join(map(str, invalid_ids))})
    AND audit_log <> 'do not delete';
    """
    print("🔹 Running Condition2 Update:")
    cursor.execute(update2)
    conn.commit()
else:
    print("✅ No condition2 mismatches found")

# ------------------------------------------------------
# 3️⃣ CONDITION 3 (Manual hardcoded cleanup)
# ------------------------------------------------------
manual_lanes = [
    ("FRS", "FRDS", "FRDS"),("FRS","FRDS","FRDS"),("GAS","GUS","GUS"),("GUS","GAS","GAS"),("GUS","D14S","D14S"),("FRDS","FRS","FRS"),("D14S","GUS","GUS")
    # add more tuples like ("SRC", "NLOC", "DEST")
]

manual_ids = []
for src, nloc, dest in manual_lanes:
    query = """
    SELECT nlc.id
    FROM next_location_configs nlc
    JOIN locations l ON nlc.location_id = l.id
    JOIN locations ln ON nlc.next_location_id = ln.id
    JOIN locations dl ON dl.pincode_id = nlc.pincode_id
      AND dl.entity_type = 'PARTNER'
      AND dl.status = 1
      AND dl.is_valmo_location = 1
    WHERE nlc.entity_type = 'MANIFEST'
      AND nlc.is_active = 1
      AND l.alias = %s
      AND ln.alias = %s
      AND dl.alias = %s;
    """
    cursor.execute(query, (src, nloc, dest))
    results = cursor.fetchall()
    manual_ids.extend([row[0] for row in results])

if manual_ids:
    update3 = f"""
    UPDATE loadshare.next_location_configs
    SET is_active = 0,
    audit_log = 'Duplicate nlc cleaner job'
    WHERE id IN ({','.join(map(str, manual_ids))});
    """
    print("🔹 Running Condition3 Update (Manual Overrides):")
    cursor.execute(update3)
    conn.commit()
else:
    print("✅ No manual override lanes found")


cursor.close()
conn.close()

