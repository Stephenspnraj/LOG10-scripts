import sys
import os
import logging
import logging.handlers

class Config_wrm:
    def __init__(self):
        self.slack_token = "pT3BHK5oIVNM8xfoDOdGOpXg"
        self.hydra_alerts_channel_url = "https://hooks.slack.com/services/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"

    # def get_db(self):
        if os.environ.get("DBINFO") == "STAGING":
            self.hydra_prime_credentials = {
                "host": "log10-staging.cco3osxqlq4g.ap-south-1.rds.amazonaws.com",
                "user": "log10_staging",
                "passwd": "A_edjsHKmDF6vajhL4go6ekP",
                "db": "wormhole-staging",
                "port": 3306
            }
            self.LOG_PREFIX = "hydra-prime" 
        else:
            self.hydra_prime_credentials = {
                "host": "wormhole-prod.cco3osxqlq4g.ap-south-1.rds.amazonaws.com",
                "user":"janus_prod",
                "passwd": "DFqvHs3*fObbli5X",
                "db": "janus_prod",
                "port": 3306
            }
            self.LOG_PREFIX = "hydra-prime" 
