#!/bin/bash
poetry env info
poetry install
