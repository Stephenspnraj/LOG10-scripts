#!/bin/bash
set -e
ssh -L 3310:log-10-replica-backup.cco3osxqlq4g.ap-south-1.rds.amazonaws.com:3306 ubuntu@log10-jb.loadshare.net -N
